//
//  TriangleView.swift
//  jfm325_p3
//
//  Created by Joey Morquecho on 4/3/20.
//  Copyright © 2020 Joey Morquecho. All rights reserved.
//

import UIKit

class TriangleView: UIView {

    override init(frame: CGRect) {
        super .init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // draw method overriden to draw triangle
    override func draw(_ rect: CGRect) {

        let path = UIBezierPath()
        path.move(to: CGPoint(x: frame.width/2, y: 0))
        path.addLine(to: CGPoint(x: 0, y: frame.height))
        path.addLine(to: CGPoint(x: frame.width, y: frame.height))
        path.close()
        
        UIColor.green.setFill()
        path.fill()
        
        UIColor.green.setStroke()
        path.stroke()
        
    }
    

}
