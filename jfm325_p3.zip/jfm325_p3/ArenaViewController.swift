//
//  ArenaViewController.swift
//  jfm325_p3
//
//  Created by Joey Morquecho on 3/29/20.
//  Copyright © 2020 Joey Morquecho. All rights reserved.
//

import UIKit

class ArenaViewController: UIViewController {
    
    // Navigation buttons for Blue Circle Arena
    var backButton: UIButton!
    var saveButton: UIButton!
    
    // Delegate and variables passed through constructor
    weak var delegate: SaveViewProtocol?
    var pointsArray: [CGPoint]!
    var arenaName: String!
    var colorArray: [UIColor]!
    var arena: String!
    
    var arenaNameLabel: UILabel!
    var textField: UITextField!
    
    // Alert for invalid input for Arena Name
    let invalidInputAlert: UIAlertController = UIAlertController(title: "Enter Arena Name", message: "Make sure to have an input for Arena Name. New shapes added will not be saved.", preferredStyle: .alert)
    
    // Constructor for all Arenas except Magical Arena
    init(delegate: SaveViewProtocol?, arena: String, points: [CGPoint], arenaName: String){
        super.init(nibName: nil, bundle: nil)
        
        self.delegate = delegate
        self.pointsArray = points
        self.arenaName = arenaName
        self.arena = arena
        
    }
    
    // Constructor for Magical Arena
    init(delegate: SaveViewProtocol?, arena: String, colors: [UIColor], points: [CGPoint], arenaName: String){
        super.init(nibName: nil, bundle: nil)
        
        self.delegate = delegate
        self.pointsArray = points
        self.arenaName = arenaName
        self.arena = arena
        self.colorArray = colors
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        invalidInputAlert.addAction(UIAlertAction(title: "Got It", style: .default, handler: nil))
        
        if (arena == "Red Square Arena"){
            view.backgroundColor = .white
            
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveRedView(sender:)))
            
        } else if (arena == "Blue Circle Arena"){
            view.backgroundColor = .white
            
            backButton = UIButton()
            backButton.setTitle("< Back", for: .normal)
            backButton.setTitleColor((#colorLiteral(red: 0/255, green: 149/255, blue: 255/255, alpha: 1)), for: .normal)
            backButton.titleLabel?.font = UIFont.systemFont(ofSize: 18)
            backButton.translatesAutoresizingMaskIntoConstraints = false
            
            backButton.addTarget(self, action: #selector(dismissViewController), for: .touchUpInside)
            view.addSubview(backButton)
            
            saveButton = UIButton()
            saveButton.setTitle("Save", for: .normal)
            saveButton.setTitleColor((#colorLiteral(red: 0/255, green: 149/255, blue: 255/255, alpha: 1)), for: .normal)
            saveButton.titleLabel?.font = UIFont.systemFont(ofSize: 18)
            saveButton.translatesAutoresizingMaskIntoConstraints = false
            
            saveButton.addTarget(self, action: #selector(saveBlueView), for: .touchUpInside)
            view.addSubview(saveButton)
            
        } else if (arena == "Magical Arena"){
            // Random background color for each time view is loaded
            view.backgroundColor = UIColor(red: CGFloat(drand48()), green: CGFloat(drand48()), blue: CGFloat(drand48()), alpha: 1.0)
            
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveMagicalView(sender:)))
            
        } else if (arena == "Green Triangle Arena") {
            view.backgroundColor = .white
            
            self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveGreenView(sender:)))
        }
        
        arenaNameLabel = UILabel()
        arenaNameLabel.text = "Arena Name: "
        arenaNameLabel.textColor = .black
        arenaNameLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(arenaNameLabel)
        
        textField = UITextField()
        textField.text = arenaName
        textField.borderStyle = .roundedRect
        textField.textColor = .black
        textField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textField)
        
        loadSavedView()
        
        setUpConstraints()
    }
    
    // Loads previously saved positions of shape views
    func loadSavedView(){
        if (arena == "Red Square Arena") {
            for point in pointsArray {
                let square = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
                square.backgroundColor = .red
                square.center = point
                view.addSubview(square)
            }
            
        } else if (arena == "Blue Circle Arena") {
            for point in pointsArray {
                let circle = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
                circle.layer.cornerRadius = 25
                circle.layer.masksToBounds = false
                circle.backgroundColor = .blue
                circle.center = point
                view.addSubview(circle)
            }
            
        } else if (arena == "Magical Arena") {
            var index = 0
            for point in pointsArray {
                let square = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
                square.backgroundColor = colorArray[index]
                index += 1
                square.center = point
                view.addSubview(square)
            }
            
        } else if (arena == "Green Triangle Arena") {
            for point in pointsArray {
                let triangle = TriangleView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
                triangle.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0)
                triangle.center = point
                view.addSubview(triangle)
            }
            
        }
    }
    
    // Adds corresponding shape to the arena view where the screen was touched
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if (arena == "Red Square Arena"){
            
            let square = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
            square.backgroundColor = .red
            square.center = touches.first!.location(in: view)
            pointsArray.append(square.center)
            view.addSubview(square)
            
        } else if (arena == "Blue Circle Arena") {
            
            let circle = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
            circle.layer.cornerRadius = 25
            circle.layer.masksToBounds = false
            circle.backgroundColor = .blue
            circle.center = touches.first!.location(in: view)
            pointsArray.append(circle.center)
            view.addSubview(circle)
            
        } else if (arena == "Magical Arena"){
            
            let newColor = UIColor(red: CGFloat(drand48()), green: CGFloat(drand48()), blue: CGFloat(drand48()), alpha: 1.0)
            colorArray.append(newColor)
            let square = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
            square.backgroundColor = newColor
            square.center = touches.first!.location(in: view)
            pointsArray.append(square.center)
            view.addSubview(square)
            
        } else if (arena == "Green Triangle Arena") {
            
            let triangle = TriangleView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
            triangle.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0) // Transparent background
            triangle.layer.masksToBounds = false
            triangle.center = touches.first!.location(in: view)
            pointsArray.append(triangle.center)
            view.addSubview(triangle)
            
        }
    }
    
    // Call to SaveViewProtocol method - saveRedView() - to save array of square positions and arena name
    @objc func saveRedView(sender: UIBarButtonItem) {
        
        // If input is valid, Arena Name and location of Squares are saved.
        // If input is blank, an alert is displayed
        let arenaName = textField.text?.replacingOccurrences(of: " ", with: "")
        if arenaName != "" {
            delegate?.saveRedView(points: pointsArray, redName: textField.text ?? "Red Square Arena")
            navigationController?.popViewController(animated: true)
        } else {
            self.present(invalidInputAlert, animated: true)
        }
    }
    
    // Call to SaveViewProtocol method - saveBlueView() - to save array of circle positions and arena name
    @objc func saveBlueView() {
        
        // If input is valid, Arena Name and location of Squares are saved.
        // If input is blank, an alert is displayed
        let arenaName = textField.text?.replacingOccurrences(of: " ", with: "")
        if arenaName != "" {
            delegate?.saveBlueView(points: pointsArray, blueName: textField.text ?? "Blue Circle Arena")
            dismissViewController()
        } else {
            self.present(invalidInputAlert, animated: true)
        }
    }

    // Call to SaveViewProtocol method - saveMagicalView() - to save array of square positions, colors of squares, and arena name
    @objc func saveMagicalView(sender: UIBarButtonItem) {
        
        // If input is valid, Arena Name and location of Squares are saved.
        // If input is blank, an alert is displayed
        let arenaName = textField.text?.replacingOccurrences(of: " ", with: "")
        if arenaName != "" {
            delegate?.saveMagicalView(points: pointsArray, colors: colorArray, magicalName: textField.text ?? "Magical Arena")
            navigationController?.popViewController(animated: true)
        } else {
            self.present(invalidInputAlert, animated: true)
        }
    }
    
    // Call to SaveViewProtocol method - saveGreenView() - to save array of triangle positions and arena name
    @objc func saveGreenView(sender: UIBarButtonItem) {
        
        // If input is valid, Arena Name and location of Squares are saved.
        // If input is blank, an alert is displayed
        let arenaName = textField.text?.replacingOccurrences(of: " ", with: "")
        if arenaName != "" {
            delegate?.saveGreenView(points: pointsArray, greenName: textField.text ?? "Green Triangle Arena")
            navigationController?.popViewController(animated: true)
        } else {
            self.present(invalidInputAlert, animated: true)
        }
    }
    
    // Dismisses the current view controller
    @objc func dismissViewController() {
        dismiss(animated: true, completion: nil)
    }
    
    func setUpConstraints() {
        
        // Arena Name Label
        NSLayoutConstraint.activate([
            arenaNameLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
            arenaNameLabel.trailingAnchor.constraint(equalTo: textField.leadingAnchor, constant: -10),
            arenaNameLabel.heightAnchor.constraint(equalToConstant: 25),
            arenaNameLabel.widthAnchor.constraint(equalToConstant: 100)
        ])
        
        // Text Field
        NSLayoutConstraint.activate([
            textField.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 25),
            textField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40),
            textField.heightAnchor.constraint(equalToConstant: 25),
            textField.widthAnchor.constraint(equalToConstant: 180)
        ])
        
        if (arena == "Blue Circle Arena") {  // Custom 'Back' and 'Save' Buttons for Blue Circle Arena
            // Back Button
            NSLayoutConstraint.activate([
                backButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 5),
                backButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 5),
                backButton.heightAnchor.constraint(equalToConstant: 30),
                backButton.widthAnchor.constraint(equalToConstant: 80)
            ])
            
            // Save Button
            NSLayoutConstraint.activate([
                saveButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 5),
                saveButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -5),
                saveButton.heightAnchor.constraint(equalToConstant: 30),
                saveButton.widthAnchor.constraint(equalToConstant: 70)
            ])
        }
    }
    
}
