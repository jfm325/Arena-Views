//
//  ViewController.swift
//  jfm325_p3
//
//  Created by Joey Morquecho on 3/12/20.
//  Copyright © 2020 Joey Morquecho. All rights reserved.
//

import UIKit

protocol SaveViewProtocol : class {
    func saveRedView(points: [CGPoint], redName: String)
    func saveBlueView(points: [CGPoint], blueName: String)
    func saveMagicalView(points: [CGPoint], colors: [UIColor], magicalName: String)
    func saveGreenView(points: [CGPoint], greenName: String)

}

class ViewController: UIViewController {
    
    // Arrays of shape locations
    var redViewPoints: [CGPoint] = []
    var blueViewPoints: [CGPoint] = []
    var greenViewPoints: [CGPoint] = []
    var magicalViewPoints: [CGPoint] = []
    
    // Array of colors of squares in Magical Arena
    var magicalColors: [UIColor] = []

    // Buttons on Home Screen
    var redButton: UIButton!
    var blueButton: UIButton!
    var magicalButton: UIButton!
    var greenButton: UIButton!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
                    
        redButton = UIButton()
        redButton.setTitle("Red Square Arena", for: .normal)
        redButton.setTitleColor(.red, for: .normal)
        redButton.translatesAutoresizingMaskIntoConstraints = false
        redButton.addTarget(self, action: #selector(pushRedArenaViewController), for: .touchUpInside)
        view.addSubview(redButton)
                
        blueButton = UIButton()
        blueButton.setTitle("Blue Circle Arena", for: .normal)
        blueButton.setTitleColor(.blue, for: .normal)
        blueButton.translatesAutoresizingMaskIntoConstraints = false
        blueButton.addTarget(self, action: #selector(presentBlueButtonModalViewController), for: .touchUpInside)
        view.addSubview(blueButton)
        
        magicalButton = UIButton()
        magicalButton.setTitle("Magical Arena", for: .normal)
        magicalButton.setTitleColor(.lightGray, for: .normal)
        magicalButton.translatesAutoresizingMaskIntoConstraints = false
        magicalButton.addTarget(self, action: #selector(pushMagicalArena), for: .touchUpInside)
        view.addSubview(magicalButton)
        
        greenButton = UIButton()
        greenButton.setTitle("Green Triangle Arena", for: .normal)
        greenButton.setTitleColor(.green, for: .normal)
        greenButton.translatesAutoresizingMaskIntoConstraints = false
        greenButton.addTarget(self, action: #selector(pushGreenTriangleArena), for: .touchUpInside)
        view.addSubview(greenButton)
        
        setUpConstraints()
    }
    
    @objc func pushRedArenaViewController() {
        let vc = ArenaViewController(delegate: self, arena: "Red Square Arena", points: redViewPoints, arenaName: redButton.title(for: .normal) ?? "Red Square Arena")
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func presentBlueButtonModalViewController() {
        let vc = ArenaViewController(delegate: self, arena: "Blue Circle Arena", points: blueViewPoints, arenaName: blueButton.title(for: .normal) ?? "Blue Circle Arena")
        self.present(vc, animated: true, completion: nil)
    }
    
    @objc func pushMagicalArena() {
        let vc = ArenaViewController(delegate: self, arena: "Magical Arena", colors: magicalColors, points: magicalViewPoints, arenaName: magicalButton.title(for: .normal) ?? "Magical Arena")
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func pushGreenTriangleArena() {
            let vc = ArenaViewController(delegate: self, arena: "Green Triangle Arena", points: greenViewPoints, arenaName: greenButton.title(for: .normal) ?? "Green Triangle Arena")
            navigationController?.pushViewController(vc, animated: true)
    }
            
    func setUpConstraints() {
               
        // Red Square Arena Button
        NSLayoutConstraint.activate([
        redButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        redButton.bottomAnchor.constraint(equalTo: blueButton.topAnchor, constant: -40),
        redButton.heightAnchor.constraint(equalToConstant: 40)
        ])
        
        // Blue Circle Arena Button (Every other button constrained to this button)
        NSLayoutConstraint.activate([
        blueButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        blueButton.centerYAnchor.constraint(equalTo:view.centerYAnchor, constant: -40),
        blueButton.heightAnchor.constraint(equalToConstant: 40)

        ])
    
        // Magical Arena Button
        NSLayoutConstraint.activate([
        magicalButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        magicalButton.topAnchor.constraint(equalTo:blueButton.bottomAnchor, constant: 40),
        magicalButton.heightAnchor.constraint(equalToConstant: 40)

        ])
        
        // Green Triangle Arena Button
        NSLayoutConstraint.activate([
        greenButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        greenButton.topAnchor.constraint(equalTo:magicalButton.bottomAnchor, constant: 40),
        greenButton.heightAnchor.constraint(equalToConstant: 40)

        ])
    }
}

extension ViewController: SaveViewProtocol {
    func saveRedView(points: [CGPoint], redName: String) {
        redViewPoints = points
        redButton.setTitle(redName, for: .normal)
    }
    
    func saveBlueView(points: [CGPoint], blueName: String) {
        blueViewPoints = points
        blueButton.setTitle(blueName, for: .normal)
    }
    
    func saveMagicalView(points: [CGPoint], colors: [UIColor], magicalName: String) {
        magicalColors = colors
        magicalViewPoints = points
        magicalButton.setTitle(magicalName, for: .normal)
    }
    
    func saveGreenView(points: [CGPoint], greenName: String) {
        greenViewPoints = points
        greenButton.setTitle(greenName, for: .normal)
    }
}
